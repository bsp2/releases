/*
 * why this is in a separate include file:
 *   well, putting this directly into the respective header file confuses the emacs syntax highlighter/indenter :-)
 */
#ifdef __cplusplus
}
#endif

