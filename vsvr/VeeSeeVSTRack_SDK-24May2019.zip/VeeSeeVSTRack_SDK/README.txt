This SDK can be used to create 3rd party plugins for the (unofficial) VST2 port of Rack
 (https://github.com/bsp2/VeeSeeVSTRack).

The included example plugin ("Template_shared") can be built with Microsoft's Visual Studio 2017 Community Edition
 (Release / x64 configuration).

When developing a new plugin, please change the "SLUG" (unique plugin identifier) in the preprocessor settings.

To run your plugin, create a folder in the VeeSeeVSTRack "vst2_bin/plugins/" directory
 (using the same name as the SLUG, e.g. "vst2_bin/plugins/myplugin/"), then copy the
"plugin.dll" and the "res/" folder into the new directory.
Duplicate the "plugin.dll" and rename the copies to "plugin.dll.fx" and "plugin.dll.instr".

Start your DAW, instantiate the VeeSeeVSTRack plugin, and your plugin modules should be ready to use.


Note: Further information on how to port Rack 0.6.x plugins to VSVR can be found here:
       https://github.com/bsp2/VeeSeeVSTRack/blob/v0.6/plugin_mini_howto.md
