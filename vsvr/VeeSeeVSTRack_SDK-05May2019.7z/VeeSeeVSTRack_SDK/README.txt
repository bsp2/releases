This SDK can be used to create 3rd party plugins for the (unofficial) VST2 port of Rack (https://github.com/bsp2/VeeSeeVSTRack).

The included example plugin ("Template_shared") can be built with Microsoft's Visual Studio 2017 Community Edition (Release / x64 configuration).

When developing a new plugin, please change the "SLUG" (unique plugin identifier) in the preprocessor settings.

To run your plugin, create a folder in the VeeSeeVSTRack "vst2_bin/plugins/" directory (using the same name as the SLUG), 
then copy the "plugin.dll" and the "res/" folder into the new directory.

Start your DAW, instantiate the VeeSeeVSTRack plugin, and your plugin modules should be ready to use.
